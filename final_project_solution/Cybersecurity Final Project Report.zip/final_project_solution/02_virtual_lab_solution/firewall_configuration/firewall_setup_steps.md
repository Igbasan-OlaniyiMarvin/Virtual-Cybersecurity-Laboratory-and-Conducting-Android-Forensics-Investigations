# Firewall Configuration Steps (Optional)

## Tools Used
- pfSense or OPNsense

## Steps
1. Create VM
2. Configure Interfaces
3. Setup NAT and DHCP

## Testing
- Verify packet filtering
- Log outputs
